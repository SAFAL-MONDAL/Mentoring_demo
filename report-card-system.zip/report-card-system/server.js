const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const uploadDir = path.join(__dirname, 'uploads');

// Ensure the uploads directory exists
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// Configure Multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
        const regNumber = req.body.regNumber;
        cb(null, `${regNumber}.pdf`);
    },
});

const upload = multer({ storage });

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve static files from the uploads directory
app.use('/uploads', express.static(uploadDir));

// Handle file uploads
app.post('/upload', upload.single('reportCard'), (req, res) => {
    res.json({ message: 'Report card uploaded successfully' });
});

// Handle viewing a report card by registration number
app.get('/view/:regNumber', (req, res) => {
    const regNumber = req.params.regNumber;
    const filePath = path.join(uploadDir, `${regNumber}.pdf`);

    if (fs.existsSync(filePath)) {
        res.send(`/uploads/${regNumber}.pdf`);
    } else {
        res.status(404).send('Report card not found');
    }
});

// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
