document.getElementById('uploadForm').onsubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    const response = await fetch('/upload', {
        method: 'POST',
        body: formData,
    });

    const result = await response.json();
    alert(result.message);
};

async function searchReportCard() {
    const regNumber = document.getElementById('searchBar').value;
    const response = await fetch(`/view/${regNumber}`);
    
    if (response.ok) {
        const reportCardURL = await response.text();
        document.getElementById('reportCardDisplay').innerHTML = `
            <iframe src="${reportCardURL}" width="100%" height="600px"></iframe>
        `;
    } else {
        alert('Report card not found');
    }
}
